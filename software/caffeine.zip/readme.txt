caffeine
===============================================================================


Run this to prevent your PC screen from locking.  It does this by simulating
that you've pressed the right context-menu key once every 59 seconds.

Double-click the icon to temporarily disable Caffeine, and permit your screen
to lock.

Under Win98:             a key down and then a key up event is simulated
Under Win2000/XP/7/8/10: a key up event is simulated

The additional event is required under Windows 98, otherwise the screen will
still lock.


Command-line options:

There are quite a few, and to avoid repeating myself, look in the About dialog
in the app to see what the options all are.


Note: if you get an error about the "side-by-side configuration" when you run
Caffeine, read this: http://www.zhornsoftware.co.uk/support/kb.pl?q=00085

-------------------------------------------------------------------------------
Copyright Tom Revell, tom.revell@zhornsoftware.co.uk
Zhorn Software, http://www.zhornsoftware.co.uk/